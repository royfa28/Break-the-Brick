github link:

https://github.com/royfa28/Break-the-Brick